package com.example.fruitsapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TableLayout;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class orderDet extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_det);

        /*Intent intent=getIntent();

        int total= intent.getIntExtra("total",0);
        String name= intent.getStringExtra("customerName");
        String phoneNumber=intent.getStringExtra("phoneNumber");*/
        String name="";
        String phoneNumber="";
        int total=0;

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            total = bundle.getInt("total");
            name= bundle.getString("customerName");
            phoneNumber=bundle.getString("phoneNumber");
        }

        TextView ordert=(TextView) findViewById(R.id.total);
        ordert.setText(String.valueOf(total));

        TableLayout tableLayout = findViewById(R.id.table);

        TableRow tableRow = new TableRow(this);

        TextView nameTextView = new TextView(this);
        nameTextView.setText("Name");
        nameTextView.setGravity(1);
        tableRow.addView(nameTextView);

        TextView numberTextView = new TextView(this);
        numberTextView.setText("Phone Number");
        numberTextView.setGravity(1);
        tableRow.addView(numberTextView);
        tableLayout.addView(tableRow);

        TableRow tableRow1 = new TableRow(this);
        TextView nameTextView1 = new TextView(this);
        nameTextView1.setText(name);
        //Log.d("print",name);
        nameTextView1.setGravity(1);
        tableRow1.addView(nameTextView1);
        TextView phoneTextView = new TextView(this);
        phoneTextView.setText(phoneNumber);
        //Log.d("phn",phoneNumber);
        phoneTextView.setGravity(1);
        tableRow1.addView(phoneTextView);
        tableLayout.addView(tableRow1);

    }
}
