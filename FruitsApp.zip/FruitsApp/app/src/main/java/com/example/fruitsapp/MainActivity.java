package com.example.fruitsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    String customerName;
    String phoneNumber;

    public static int total=0;
    public static int appleCount=0;
    public static int orangeCount=0;
    public static int pineAppleCount=0;
    public static int guavaCount=0;
    public static int grapesCount=0;

    public void apple(View view){
        appleCount++;
        TextView appleView=(TextView) findViewById(R.id.appleQuantity);
        appleView.setText(String.valueOf(appleCount));
    }

    public void orange(View view){
        orangeCount++;
        TextView orangeView=(TextView) findViewById(R.id.orangeQuantity);
        orangeView.setText(String.valueOf(orangeCount));
    }

    public void pineApple(View view){
        pineAppleCount++;
        TextView pineAppleView=(TextView) findViewById(R.id.pineAppleQuantity);
        pineAppleView.setText(String.valueOf(pineAppleCount));
    }

    public void guava(View view){
        guavaCount++;
        TextView guavaView=(TextView) findViewById(R.id.guavaQuantity);
        guavaView.setText(String.valueOf(guavaCount));
    }

    public void grapes(View view){
        grapesCount++;
        TextView grapesView=(TextView) findViewById(R.id.grapesQuantity);
        grapesView.setText(String.valueOf(grapesCount));
    }

    public void order(View view){
        customerName=findViewById(R.id.customerName).toString();
        phoneNumber=findViewById(R.id.phoneNumber).toString();
        total=(appleCount*100)+(orangeCount*60)+(pineAppleCount*50)+(guavaCount*60)+(grapesCount*40);
        Intent myIntent = new Intent(MainActivity.this, orderDet.class);
        myIntent.putExtra("total", total);
        myIntent.putExtra("customerName",customerName);
        myIntent.putExtra("phoneNumber",phoneNumber);//Optional parameters
        MainActivity.this.startActivity(myIntent);
    }

    public void reset(View view){
        total=0;

        TextView appleView=(TextView) findViewById(R.id.appleQuantity);
        appleView.setText(String.valueOf(0));
        appleCount=0;

        TextView orangeView=(TextView) findViewById(R.id.orangeQuantity);
        orangeView.setText(String.valueOf(0));
        orangeCount=0;

        TextView pineAppleView=(TextView) findViewById(R.id.pineAppleQuantity);
        pineAppleView.setText(String.valueOf(0));
        pineAppleCount=0;

        TextView guavaView=(TextView) findViewById(R.id.guavaQuantity);
        guavaView.setText(String.valueOf(0));
        guavaCount=0;

        TextView grapesView=(TextView) findViewById(R.id.grapesQuantity);
        grapesView.setText(String.valueOf(0));
        grapesCount=0;

    }

}